// This file has been replaced by ScrollSunrays.tsx for a cleaner animation system
// If you need the old interactive system, see _unused_InteractiveSunrays.tsx

export function InteractiveSunrays() {
  return null;
}

export function SunrayProvider() {
  return null;
}

export function useSunrays() {
  throw new Error('useSunrays has been deprecated. The new ScrollSunrays system does not require context providers.');
}

export function InteractiveSection() {
  return null;
}